package com.example.electric_scooters_rental_onboarding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
